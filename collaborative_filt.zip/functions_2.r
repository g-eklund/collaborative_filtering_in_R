#Collaborative Filtering
cat("reading functions... ")
#Get data from some source
require(reshape2)
require(recommenderlab)
get_data <- function(data="normal", sparsity_fraction = 0.8, level = c("kund", "segment")){
  
  
  if (data == "demo_binary"){
    nprods <- 10
    ncust <- 1000
    df <- matrix(floor(runif(nprods*ncust, min=0, max = 2/sparsity_fraction+1)), nrow = ncust)
    df[df == floor((2/sparsity_fraction+1)/2)] <-1
    df[df != 1] <- 0
    row.names(df)<- paste("user", 1:ncust, sep = "")
    colnames(df)<- paste("product", 1:nprods, sep = "")
    cat(paste("The size of data is", nrow(df),"rows and", ncol(df), "cols"))
    df <- as(df,"binaryRatingMatrix")
  }
  if (data == "demo_graded"){
    nprods <- 10
    ncust <- 1000
    df <- matrix(floor(runif(nprods*ncust, min=0, max = 2/sparsity_fraction+1)), nrow = ncust)
    df[df == floor((2/sparsity_fraction+1)/2)] <-1
    df[df != 1] <- 0
    row.names(df)<- paste("user", 1:ncust, sep = "")
    colnames(df)<- paste("product", 1:nprods, sep = "")
    cat(paste("The size of data is", nrow(df),"rows and", ncol(df), "cols"))
    df <- as(df,"binaryRatingMatrix")
  }
  if (data == "normal"){
    df <- read.csv2("selling-data.csv", stringsAsFactors = F, header = T)[,1:22]
    if (level=="kund"){
      df2 <- reshape2::acast(df,  Customer.Name ~ Product.Group, fun.aggregate = length, value.var = "No.of.Transactions")
    }
    if (level=="segment"){
      df2 <- reshape2::acast(df,  Customer.Segment ~ Product.Group, fun.aggregate = length, value.var = "No.of.Transactions")
    }
    df2[df2 > 0] <- 1
    df2[df2 == 0] <- 0
    cat(paste("The size of data is", nrow(df2),"rows and", ncol(df2), "cols"))
    df <- as(df2,"binaryRatingMatrix")
  }
  if (data == "graded"){
    df <- read.csv2("selling-data.csv", stringsAsFactors = F, header = T)[,1:22]
    if (level=="kund"){
      df2 <- reshape2::acast(df,  Customer.Name ~ Product.Group, fun.aggregate = length, value.var = "No.of.Transactions")
    }
    if (level=="segment"){
      df2 <- reshape2::acast(df,  Customer.Segment ~ Product.Group, fun.aggregate = length, value.var = "No.of.Transactions")
    }
    df2[df2 == 0] <- 0
    cat(paste("The size of data is", nrow(df2),"rows and", ncol(df2), "cols"))
    df <- as(df2,"realRatingMatrix")
  }
  
  return(df)
}

GetRecommendations <- function(user = NULL, n_of_recommendations = 3){
  
  ind <- grep(user, row.names(recommendations))
  recommendations_for_user <- sort(recommendations[ind,], na.last = T, decreasing = T)[1:n_of_recommendations]
  try(if(is.na(ind)){ 
    stop("Ingen med det namnet")
    return(NULL)})
  cat(paste("Topprekommendationer f�r", user, " �r: \n"))
  for (i in 1:length(recommendations_for_user))
    {
    cat(paste("Rekommendation ", i, ": ", names(recommendations_for_user[i]), "\n"))
    }
  return(recommendations_for_user)
}


GetManualRecommendations <- function(){
  user <-  readline(prompt="Vem vill du ha rekommendationer f�r: ")
  n_of_recommendations <-  readline(prompt="Hur m�nga rekommendationer vill du ha?: ")
  ind <- grep(user, row.names(recommendations))
  recommendations_for_user <- sort(recommendations[ind,], na.last = T, decreasing = T)[1:n_of_recommendations]
  
  try(if(is.na(ind)){ 
    stop("Ingen med det namnet")})
  cat(paste("Topprekommendationer f�r", user, "�r: \n"))
  for (i in 1:length(recommendations_for_user))
  {
    cat(paste("Rekommendation ", i, ": ", names(recommendations_for_user[i]), "\n"))
  }
  
}


cat("All functions read.")



