
#install.packages("recommenderlab")
#install.packages("reshape2")
library(recommenderlab)
library(reshape2)
source("functions_2.r")



df2 <- get_data(data = "normal", level = "kund") 


rec <- Recommender(data = df2,method="UBCF", param=list(method="Cosine",nn=20))
recommended <- predict(rec, df2[1:nrow(df2)], type="topNList")
recommendations <- as(recommended, "matrix")
df4 <- melt(recommendations, id= c("Var1"))
names(df4) <- c("Name", "Produkt", "Styrka")
#write.csv(recommendations, file = "output_UBCF.csv") #

GetRecommendations("Shami")

GetManualRecommendations()
recommendations+df2







